
import SwiftUI
import CryptoKit
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreGraphics

import AVFoundation


struct QRCodeOverlay: View {
    let qrCode: String
    
    var body: some View {
        let qrImage = generateQRCodeImage(qrCode: qrCode)
        return Image(uiImage: qrImage)
            .resizable()
            .aspectRatio(contentMode: .fill)
            .opacity(0.1)
    }
    
    func generateQRCodeImage(qrCode: String) -> UIImage {
        let filter = CIFilter.qrCodeGenerator()
        let data = qrCode.data(using: .ascii)
        filter.setValue(data, forKey: "inputMessage")
        let transform = CGAffineTransform(scaleX: 10, y: 10)
        if let outputImage = filter.outputImage?.transformed(by: transform) {
            let context = CIContext()
            if let cgImage = context.createCGImage(outputImage, from: outputImage.extent) {
                let uiImage = UIImage(cgImage: cgImage)
                return uiImage
            }
        }
        return UIImage()
    }
}


struct ContentView: View {
    @State private var showCaptureImageView = false
    @State private var image: UIImage?
    
    var body: some View {
        VStack {
            if image != nil {
                var qrCodeText = calculateHash(image: image!);
                Image(uiImage: image!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding()
                    .overlay(QRCodeOverlay(qrCode: qrCodeText).padding(50), alignment: .center)
                Text("Image hash: \(qrCodeText)")
            } else {
                Text("Take a photo to calculate its hash")
            }
            
            Button("Take Photo") {
                self.showCaptureImageView.toggle()
            }
            .sheet(isPresented: $showCaptureImageView) {
                CaptureImageView(isShown: self.$showCaptureImageView, image: self.$image)
            }
        }
    }
    
    func calculateHash(image: UIImage) -> String {
        guard let imageData = image.jpegData(compressionQuality: 1.0) else { return "no image data" }
        let hash = Insecure.SHA1.hash(data: imageData)
        return hash.map { String(format: "%02hhx", $0) }.joined()
    }
}


extension AVDepthData {
    var depthDataMap: CVPixelBuffer {
        return depthDataMap as CVPixelBuffer
    }
}

struct CaptureImageView {
    @Binding var isShown: Bool
    @Binding var image: UIImage?

    func makeCoordinator() -> Coordinator {
        return Coordinator(isShown: $isShown, image: $image)
    }
}

extension CaptureImageView: UIViewControllerRepresentable {
    typealias UIViewControllerType = UIImagePickerController
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<CaptureImageView>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<CaptureImageView>) {
        
    }
}

class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate, AVCapturePhotoCaptureDelegate {
    @Binding var isShown: Bool
    @Binding var image: UIImage?
    
    
    
    private let photoOutput = AVCapturePhotoOutput()
    private let session = AVCaptureSession()
    private let context = CIContext()
    

    init(isShown: Binding<Bool>, image: Binding<UIImage?>) {
        _isShown = isShown
        _image = image
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let uiImage = info[.originalImage] as? UIImage {
            image = uiImage
        }

        isShown = false
    }
    
    private func configureSession() {
        guard let device = AVCaptureDevice.default(.builtInDualCamera, for: .video, position: .back) else { return }
        let input = try? AVCaptureDeviceInput(device: device)
        guard let photoOutputConnection = photoOutput.connection(with: .video) else { return }
        photoOutputConnection.videoOrientation = .portrait

        session.sessionPreset = .photo
        session.addInput(input!)
        session.addOutput(photoOutput)
    }

    private func capturePhoto() {
        let photoSettings = AVCapturePhotoSettings()
        photoSettings.isDepthDataDeliveryEnabled = true

        photoOutput.capturePhoto(with: photoSettings, delegate: self)
    }
    
    
    

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        isShown = false
    }
}

