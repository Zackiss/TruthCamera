//
//  TrustCamApp.swift
//  TrustCam
//
//  Created by Andrew on 2023/4/6.
//

import SwiftUI

@main
struct TrustCamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
